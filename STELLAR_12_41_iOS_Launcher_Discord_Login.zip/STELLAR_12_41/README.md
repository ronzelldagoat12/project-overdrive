# STELLAR 12.41 — iOS Prototype

An original, offline iOS battle-royale prototype with an agency/spy-season theme.

## Included
- SwiftUI launcher with build selector
- Original POI catalog and map scene
- Selectable original agent outfits
- Daily rotating sample cosmetic shop (local deterministic rotation)
- Late Game Arena mode
- SpriteKit top-down gameplay: movement joystick, auto-aim fire button, enemy bots, health, eliminations and closing safe zone

## Requirements
- macOS with Xcode 15 or later
- iOS 16.0+
- iPhone simulator or a physical iPhone

## Open and run
1. Unzip the project.
2. Open `STELLAR.xcodeproj` in Xcode.
3. Select an iPhone simulator or connected iPhone.
4. Set your development team under Signing & Capabilities if installing on a device.
5. Press Run.

## Controls
- Drag the left virtual joystick to move.
- Hold the red fire control to shoot toward the nearest bot.
- Tap Leave to return to the launcher.

## Important scope notes
This is a playable prototype, not Epic's Fortnite client and not a loader for Fortnite build 12.41. It does not include Epic servers, matchmaking, copyrighted Fortnite assets, original Fortnite skins, or a real-money store. The 12.41 label is a project theme/build selection, not compatibility with Fortnite's proprietary binary or services.

The shop uses a local sample catalog and rotates based on the device's calendar day. It does not process purchases or sync across devices. Multiplayer, cloud saves, server-authoritative inventory, 3D assets, audio, anti-cheat, and production-grade networking are not included in this starter.


## Login screen / Discord OAuth setup

The app now opens on a STELLAR sign-in page with:
- Continue with Discord button
- Continue as Guest button
- Persistent local guest session using `@AppStorage`

The Discord button is an OAuth integration placeholder, not a live verified Discord login yet. To activate it:
1. Create a Discord application in the Discord Developer Portal.
2. Add the app's redirect URI (for example `stellar://discord-callback`) to the OAuth2 redirect list.
3. Add the Discord Application ID to the login configuration in `ContentView.swift`.
4. Implement the authorization-code callback and exchange the code through a secure backend.
5. Store only the minimum account identity/token data needed, securely; never embed the Discord client secret in the iOS app.

The current project intentionally does not pretend a user is authenticated with Discord before OAuth verification succeeds.
