import SwiftUI
import SpriteKit

enum StellarTab: String, CaseIterable {
    case home = "LAUNCHER"
    case locker = "LOCKER"
    case shop = "ITEM SHOP"
    case arena = "LATE GAME"
}

struct LauncherDashboardView: View {
    @State private var tab: StellarTab = .home
    @State private var selectedSkin = Skin.catalog[0]
    @State private var selectedBuild = "12.41"
    @State private var showGame = false
    @State private var arenaMode = false

    private let gold = Color(red: 0.86, green: 0.70, blue: 0.34)

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(red: 0.08, green: 0.075, blue: 0.055), .black],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                header
                HStack(spacing: 8) {
                    ForEach(StellarTab.allCases, id: \.self) { item in
                        Button { tab = item } label: {
                            Text(item.rawValue)
                                .font(.system(size: 10, weight: .heavy, design: .rounded))
                                .tracking(1)
                                .foregroundStyle(tab == item ? .black : gold)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(tab == item ? gold : Color.white.opacity(0.055))
                                .clipShape(RoundedRectangle(cornerRadius: 10))
                                .overlay(RoundedRectangle(cornerRadius: 10).stroke(gold.opacity(0.35), lineWidth: 1))
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)

                ScrollView {
                    Group {
                        switch tab {
                        case .home: launcher
                        case .locker: locker
                        case .shop: shop
                        case .arena: arena
                        }
                    }
                    .padding(16)
                }
            }
        }
        .fullScreenCover(isPresented: $showGame) {
            GameScreen(skin: selectedSkin, arenaMode: arenaMode)
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("✦ STELLAR")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(gold)
                Text("AGENCY OPERATIONS  •  iOS")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .tracking(2)
                    .foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 4) {
                Text("BUILD \(selectedBuild)")
                    .font(.system(size: 11, weight: .heavy, design: .monospaced))
                    .foregroundStyle(gold)
                Text("PROTOTYPE ONLINE")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .foregroundStyle(.green)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 8)
    }

    private var launcher: some View {
        VStack(alignment: .leading, spacing: 16) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 20)
                    .fill(LinearGradient(colors: [Color(red: 0.28, green: 0.22, blue: 0.10), .black],
                                         startPoint: .topTrailing, endPoint: .bottomLeading))
                Circle().fill(gold.opacity(0.13)).frame(width: 210).blur(radius: 5).offset(x: 180, y: -35)
                VStack(alignment: .leading, spacing: 8) {
                    Text("OPERATION: STELLAR")
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .tracking(2).foregroundStyle(gold)
                    Text("THE ISLAND\nIS YOURS.")
                        .font(.system(size: 34, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Drop in. Gear up. Outlast the island.")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.7))
                }
                .padding(20)
            }
            .frame(height: 205)
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(gold.opacity(0.45), lineWidth: 1))

            sectionTitle("GAME CONFIGURATION", subtitle: "Select your deployment build")
            HStack {
                Text("GAME BUILD")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.6))
                Spacer()
                Picker("Build", selection: $selectedBuild) {
                    Text("12.41").tag("12.41")
                    Text("12.30").tag("12.30")
                    Text("12.00").tag("12.00")
                }
                .tint(gold)
                .pickerStyle(.menu)
            }
            .padding(14)
            .background(Color.white.opacity(0.055))
            .clipShape(RoundedRectangle(cornerRadius: 12))

            Button {
                arenaMode = false
                showGame = true
            } label: {
                Label("DEPLOY TO ISLAND", systemImage: "play.fill")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .tracking(1)
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 17)
                    .background(gold)
                    .clipShape(RoundedRectangle(cornerRadius: 13))
            }

            sectionTitle("ISLAND INTEL", subtitle: "Original locations built for STELLAR")
            ForEach(POI.catalog.prefix(4)) { poi in poiRow(poi) }
        }
    }

    private var locker: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("AGENT LOCKER", subtitle: "Original outfits • Choose your operative")
            ForEach(Skin.catalog) { skin in
                Button { selectedSkin = skin } label: {
                    HStack(spacing: 13) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 12).fill(skin.color.opacity(0.2))
                            Image(systemName: "person.fill")
                                .font(.system(size: 28))
                                .foregroundStyle(skin.color)
                        }.frame(width: 58, height: 58)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(skin.name).font(.system(size: 14, weight: .heavy)).foregroundStyle(.white)
                            Text(skin.rarity.uppercased()).font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(skin.color)
                        }
                        Spacer()
                        if selectedSkin.id == skin.id {
                            Image(systemName: "checkmark.circle.fill").foregroundStyle(Color.stellarGold)
                        } else {
                            Text("EQUIP").font(.system(size: 9, weight: .bold)).foregroundStyle(.white.opacity(0.5))
                        }
                    }
                    .padding(12)
                    .background(Color.white.opacity(selectedSkin.id == skin.id ? 0.10 : 0.045))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(selectedSkin.id == skin.id ? Color.stellarGold : .white.opacity(0.08), lineWidth: 1))
                }
            }
        }
    }

    private var shop: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("DAILY ITEM SHOP", subtitle: "Original cosmetics • Rotates daily")
            Text("NEXT ROTATION: \(ShopCatalog.nextRotationText)")
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundStyle(Color.stellarGold)
            ForEach(ShopCatalog.dailyItems) { item in
                HStack(spacing: 12) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12).fill(item.color.opacity(0.18))
                        Image(systemName: item.symbol).font(.system(size: 25)).foregroundStyle(item.color)
                    }.frame(width: 62, height: 62)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.name).font(.system(size: 13, weight: .heavy)).foregroundStyle(.white)
                        Text(item.kind.uppercased()).font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(item.color)
                    }
                    Spacer()
                    Text("\(item.price) C").font(.system(size: 12, weight: .black, design: .rounded)).foregroundStyle(Color.stellarGold)
                }
                .padding(12)
                .background(Color.white.opacity(0.05))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            Text("Prototype shop: cosmetic listings are local sample data. No real-money purchases are enabled.")
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.45))
                .padding(.top, 4)
        }
    }

    private var arena: some View {
        VStack(alignment: .leading, spacing: 15) {
            sectionTitle("LATE GAME ARENA", subtitle: "Fast final-circle practice")
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(Color(red: 0.12, green: 0.08, blue: 0.06))
                Circle().stroke(Color.stellarGold.opacity(0.8), lineWidth: 2).frame(width: 145, height: 145)
                Circle().fill(Color.red.opacity(0.12)).frame(width: 145, height: 145)
                Image(systemName: "scope").font(.system(size: 48, weight: .light)).foregroundStyle(Color.stellarGold)
            }.frame(height: 190)
            infoRow("PLAYERS", value: "12")
            infoRow("STARTING LOADOUT", value: "AR • SHOTGUN • HEALS")
            infoRow("ZONE", value: "FAST CLOSING")
            infoRow("SCORING", value: "ELIMINATIONS + SURVIVAL")
            Button {
                arenaMode = true
                showGame = true
            } label: {
                Label("ENTER LATE GAME", systemImage: "scope")
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity).padding(.vertical, 17)
                    .background(Color.stellarGold).clipShape(RoundedRectangle(cornerRadius: 13))
            }
        }
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 14, weight: .black, design: .rounded)).tracking(1).foregroundStyle(Color.stellarGold)
            Text(subtitle).font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.5))
        }.padding(.top, 5)
    }

    private func poiRow(_ poi: POI) -> some View {
        HStack {
            Image(systemName: poi.symbol).foregroundStyle(Color.stellarGold).frame(width: 28)
            VStack(alignment: .leading, spacing: 3) {
                Text(poi.name).font(.system(size: 12, weight: .bold)).foregroundStyle(.white)
                Text(poi.description).font(.system(size: 9)).foregroundStyle(.white.opacity(0.5))
            }
            Spacer()
            Text(poi.type.uppercased()).font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(Color.stellarGold)
        }.padding(11).background(Color.white.opacity(0.045)).clipShape(RoundedRectangle(cornerRadius: 11))
    }

    private func infoRow(_ label: String, value: String) -> some View {
        HStack {
            Text(label).font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.5))
            Spacer()
            Text(value).font(.system(size: 10, weight: .heavy, design: .monospaced)).foregroundStyle(Color.stellarGold)
        }.padding(13).background(Color.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

extension Color {
    static let stellarGold = Color(red: 0.86, green: 0.70, blue: 0.34)
}


// MARK: - App entry and account gate

struct ContentView: View {
    @AppStorage("stellarSignedIn") private var isSignedIn = false

    var body: some View {
        Group {
            if isSignedIn {
                LauncherDashboardView()
            } else {
                StellarLoginView {
                    isSignedIn = true
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct StellarLoginView: View {
    let onContinue: () -> Void
    @State private var showDiscordSetup = false
    @State private var showGuestNotice = false

    // Replace this placeholder with the Application ID from your Discord Developer Portal.
    // A production OAuth flow also needs a secure backend to exchange the authorization code.
    private let discordClientID = "ADD_YOUR_DISCORD_CLIENT_ID"

    private let gold = Color.stellarGold

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, Color(red: 0.10, green: 0.085, blue: 0.055), .black],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            Circle()
                .fill(gold.opacity(0.10))
                .frame(width: 280, height: 280)
                .blur(radius: 55)
                .offset(x: 120, y: -210)

            VStack(spacing: 0) {
                Spacer()

                ZStack {
                    RoundedRectangle(cornerRadius: 27)
                        .fill(Color.white.opacity(0.035))
                        .frame(width: 104, height: 104)
                        .overlay(RoundedRectangle(cornerRadius: 27)
                            .stroke(gold.opacity(0.55), lineWidth: 1))
                    Image(systemName: "sparkles")
                        .font(.system(size: 43, weight: .light))
                        .foregroundStyle(gold)
                }

                Text("STELLAR")
                    .font(.system(size: 35, weight: .black, design: .rounded))
                    .tracking(5)
                    .foregroundStyle(gold)
                    .padding(.top, 22)

                Text("AGENCY OPERATIONS")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .tracking(3)
                    .foregroundStyle(.white.opacity(0.55))
                    .padding(.top, 7)

                VStack(spacing: 8) {
                    Text("WELCOME, AGENT")
                        .font(.system(size: 20, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Sign in to access your STELLAR launcher,\nlocker, daily shop and arena.")
                        .font(.system(size: 12, weight: .medium))
                        .multilineTextAlignment(.center)
                        .lineSpacing(4)
                        .foregroundStyle(.white.opacity(0.55))
                }
                .padding(.top, 42)

                Button {
                    showDiscordSetup = true
                } label: {
                    HStack(spacing: 11) {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.system(size: 18, weight: .bold))
                        Text("CONTINUE WITH DISCORD")
                            .font(.system(size: 12, weight: .black, design: .rounded))
                            .tracking(1)
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 17)
                    .background(Color(red: 0.34, green: 0.39, blue: 0.88))
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                }
                .padding(.top, 30)

                Button {
                    showGuestNotice = true
                    onContinue()
                } label: {
                    Text("CONTINUE AS GUEST")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .tracking(1.5)
                        .foregroundStyle(gold)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(Color.white.opacity(0.045))
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                        .overlay(RoundedRectangle(cornerRadius: 13)
                            .stroke(gold.opacity(0.3), lineWidth: 1))
                }
                .padding(.top, 12)

                Text("BUILD 12.41  •  iOS  •  ORIGINAL GAME PROTOTYPE")
                    .font(.system(size: 8, weight: .bold, design: .monospaced))
                    .tracking(1)
                    .foregroundStyle(.white.opacity(0.30))
                    .padding(.top, 28)

                Spacer()
                Text("By continuing, you agree to use STELLAR's prototype features.")
                    .font(.system(size: 9))
                    .foregroundStyle(.white.opacity(0.30))
                    .padding(.bottom, 18)
            }
            .padding(.horizontal, 26)
        }
        .alert("Discord sign-in setup required", isPresented: $showDiscordSetup) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("The Discord login screen is included. To activate real account sign-in, add your Discord Application ID, register the STELLAR redirect URL, and connect a secure OAuth backend. Do not put a Discord client secret inside the iOS app. Until that is configured, use Continue as Guest.")
        }
    }
}
