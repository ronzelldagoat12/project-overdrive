import SwiftUI
import SpriteKit

struct GameScreen: View {
    let skin: Skin
    let arenaMode: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var moveVector: CGVector = .zero
    @State private var fireHeld = false
    @State private var scene = StellarGameScene(size: CGSize(width: 900, height: 900))

    var body: some View {
        ZStack {
            SpriteView(scene: configuredScene, options: [.ignoresSiblingOrder])
                .ignoresSafeArea()
            VStack {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(arenaMode ? "LATE GAME ARENA" : "STELLAR ISLAND")
                            .font(.system(size: 12, weight: .black, design: .monospaced))
                        Text("AGENT: \(skin.name.uppercased())")
                            .font(.system(size: 9, weight: .bold, design: .monospaced))
                            .foregroundStyle(Color.stellarGold)
                    }
                    Spacer()
                    Button("LEAVE") { dismiss() }
                        .font(.system(size: 10, weight: .heavy))
                        .padding(10).background(.black.opacity(0.65))
                        .clipShape(RoundedRectangle(cornerRadius: 9))
                }
                .padding(.horizontal, 18).padding(.top, 12)
                Spacer()
                HStack(alignment: .bottom) {
                    JoystickView(vector: $moveVector)
                        .frame(width: 125, height: 125)
                    Spacer()
                    VStack(spacing: 12) {
                        Text("FIRE").font(.system(size: 9, weight: .black, design: .monospaced))
                        Circle()
                            .fill(Color.red.opacity(0.8))
                            .overlay(Circle().stroke(.white.opacity(0.7), lineWidth: 2))
                            .overlay(Image(systemName: "scope").font(.system(size: 27, weight: .bold)))
                            .frame(width: 76, height: 76)
                            .gesture(DragGesture(minimumDistance: 0)
                                .onChanged { _ in fireHeld = true; scene.fire() }
                                .onEnded { _ in fireHeld = false })
                    }
                }
                .padding(.horizontal, 22).padding(.bottom, 30)
            }
        }
        .statusBarHidden()
        .onChange(of: moveVector) { value in scene.moveVector = value }
    }

    private var configuredScene: SKScene {
        scene.scaleMode = .resizeFill
        scene.configure(arenaMode: arenaMode, skin: skin)
        return scene
    }
}

struct JoystickView: View {
    @Binding var vector: CGVector
    @State private var knob: CGSize = .zero
    private let radius: CGFloat = 43

    var body: some View {
        ZStack {
            Circle().fill(.black.opacity(0.48)).overlay(Circle().stroke(.white.opacity(0.35), lineWidth: 2))
            Circle().fill(Color.stellarGold.opacity(0.9)).frame(width: 42, height: 42)
                .offset(knob)
        }
        .gesture(DragGesture(minimumDistance: 0)
            .onChanged { value in
                let dx = value.location.x - 62.5
                let dy = value.location.y - 62.5
                let length = max(1, hypot(dx, dy))
                let scale = min(radius, length) / length
                knob = CGSize(width: dx * scale, height: dy * scale)
                vector = CGVector(dx: knob.width / radius, dy: -knob.height / radius)
            }
            .onEnded { _ in knob = .zero; vector = .zero })
    }
}
