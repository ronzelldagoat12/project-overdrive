import SpriteKit

final class StellarGameScene: SKScene {
    var moveVector = CGVector.zero
    private var player = SKShapeNode(circleOfRadius: 17)
    private var enemies: [SKShapeNode] = []
    private var bullets: [SKShapeNode] = []
    private var poiNodes: [SKNode] = []
    private var arenaMode = false
    private var configured = false
    private var lastUpdate: TimeInterval = 0
    private var lastShot: TimeInterval = 0
    private var health = 100
    private var eliminations = 0
    private var stormRadius: CGFloat = 330
    private var storm: SKShapeNode!
    private var hud: SKLabelNode!
    private var healthLabel: SKLabelNode!
    private var zoneLabel: SKLabelNode!

    func configure(arenaMode: Bool, skin: Skin) {
        guard !configured else { return }
        configured = true
        self.arenaMode = arenaMode
        backgroundColor = SKColor(red: 0.12, green: 0.24, blue: 0.17, alpha: 1)
        physicsWorld.gravity = .zero
        buildWorld()
        buildPlayer(color: SKColor(skin.color))
        buildHUD()
        spawnEnemies(count: arenaMode ? 11 : 6)
        if arenaMode { stormRadius = 230 }
    }

    private func buildWorld() {
        let ground = SKShapeNode(rectOf: CGSize(width: 760, height: 760), cornerRadius: 90)
        ground.fillColor = SKColor(red: 0.17, green: 0.31, blue: 0.21, alpha: 1)
        ground.strokeColor = SKColor(red: 0.32, green: 0.43, blue: 0.29, alpha: 1)
        ground.lineWidth = 12
        addChild(ground)

        for i in 0..<34 {
            let tree = SKShapeNode(circleOfRadius: CGFloat(8 + (i % 3) * 3))
            tree.fillColor = SKColor(red: 0.08, green: 0.20, blue: 0.12, alpha: 1)
            tree.strokeColor = .clear
            tree.position = CGPoint(x: CGFloat((i * 137) % 680) - 340,
                                    y: CGFloat((i * 197) % 680) - 340)
            addChild(tree)
        }

        for poi in POI.catalog {
            let node = SKNode()
            node.position = CGPoint(x: (poi.x - 0.5) * 620, y: (0.5 - poi.y) * 620)
            let building = SKShapeNode(rectOf: CGSize(width: 70, height: 48), cornerRadius: 5)
            building.fillColor = SKColor(red: 0.34, green: 0.34, blue: 0.31, alpha: 1)
            building.strokeColor = .white.withAlphaComponent(0.4)
            node.addChild(building)
            let label = SKLabelNode(text: poi.name)
            label.fontName = "AvenirNext-Bold"
            label.fontSize = 10
            label.fontColor = .white
            label.position = CGPoint(x: 0, y: 34)
            node.addChild(label)
            addChild(node)
            poiNodes.append(node)
        }

        storm = SKShapeNode(circleOfRadius: stormRadius)
        storm.strokeColor = .cyan.withAlphaComponent(0.85)
        storm.lineWidth = 5
        storm.fillColor = .cyan.withAlphaComponent(0.035)
        storm.zPosition = 2
        addChild(storm)
    }

    private func buildPlayer(color: SKColor) {
        player.fillColor = color
        player.strokeColor = .white
        player.lineWidth = 3
        player.position = .zero
        player.zPosition = 10
        addChild(player)
    }

    private func buildHUD() {
        hud = SKLabelNode(fontNamed: "AvenirNext-Heavy")
        hud.fontSize = 15
        hud.fontColor = .white
        hud.horizontalAlignmentMode = .left
        hud.position = CGPoint(x: -size.width / 2 + 24, y: size.height / 2 - 65)
        hud.zPosition = 100
        addChild(hud)

        healthLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
        healthLabel.fontSize = 13
        healthLabel.fontColor = .green
        healthLabel.horizontalAlignmentMode = .left
        healthLabel.position = CGPoint(x: -size.width / 2 + 24, y: size.height / 2 - 88)
        healthLabel.zPosition = 100
        addChild(healthLabel)

        zoneLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
        zoneLabel.fontSize = 11
        zoneLabel.fontColor = .cyan
        zoneLabel.position = CGPoint(x: 0, y: -size.height / 2 + 35)
        zoneLabel.zPosition = 100
        addChild(zoneLabel)
    }

    private func spawnEnemies(count: Int) {
        for i in 0..<count {
            let enemy = SKShapeNode(circleOfRadius: 14)
            enemy.fillColor = .systemRed
            enemy.strokeColor = .white
            enemy.lineWidth = 2
            enemy.position = CGPoint(x: CGFloat((i * 113) % 500) - 250,
                                     y: CGFloat((i * 167) % 500) - 250)
            enemy.zPosition = 9
            addChild(enemy)
            enemies.append(enemy)
        }
    }

    func fire() {
        let now = CACurrentMediaTime()
        guard now - lastShot > 0.22 else { return }
        lastShot = now
        let bullet = SKShapeNode(circleOfRadius: 5)
        bullet.fillColor = .yellow
        bullet.strokeColor = .clear
        bullet.position = player.position
        bullet.zPosition = 12
        addChild(bullet)
        let nearest = enemies.min { distance($0.position, player.position) < distance($1.position, player.position) }
        let target = nearest?.position ?? CGPoint(x: player.position.x + 1, y: player.position.y)
        let dx = target.x - player.position.x
        let dy = target.y - player.position.y
        let length = max(1, hypot(dx, dy))
        let destination = CGPoint(x: player.position.x + dx / length * 600,
                                  y: player.position.y + dy / length * 600)
        bullet.run(.sequence([.move(to: destination, duration: 0.55), .removeFromParent()]))
        bullets.append(bullet)
    }

    override func update(_ currentTime: TimeInterval) {
        let dt = min(0.04, currentTime - (lastUpdate == 0 ? currentTime : lastUpdate))
        lastUpdate = currentTime
        player.position.x += moveVector.dx * 230 * dt
        player.position.y += moveVector.dy * 230 * dt
        player.position.x = min(355, max(-355, player.position.x))
        player.position.y = min(355, max(-355, player.position.y))

        for enemy in enemies {
            let dx = player.position.x - enemy.position.x
            let dy = player.position.y - enemy.position.y
            let d = max(1, hypot(dx, dy))
            if d < 260 {
                enemy.position.x += dx / d * 48 * dt
                enemy.position.y += dy / d * 48 * dt
            }
            if d < 28 {
                health = max(0, health - Int(dt * 12))
            }
        }

        for bullet in bullets {
            guard bullet.parent != nil else { continue }
            for enemy in enemies where enemy.parent != nil {
                if distance(bullet.position, enemy.position) < 21 {
                    enemy.removeFromParent()
                    bullet.removeFromParent()
                    eliminations += 1
                    break
                }
            }
        }

        stormRadius = max(65, stormRadius - CGFloat(dt) * (arenaMode ? 3.0 : 1.2))
        storm.path = CGPath(ellipseIn: CGRect(x: -stormRadius, y: -stormRadius,
                                              width: stormRadius * 2, height: stormRadius * 2), transform: nil)
        hud.text = "\(arenaMode ? "ARENA" : "ISLAND")  •  ELIMS \(eliminations)"
        healthLabel.text = "HEALTH \(health)"
        zoneLabel.text = "SAFE ZONE CLOSING"
        if health == 0 {
            zoneLabel.text = "KNOCKED OUT • CLOSE AND REDEPLOY"
        }
    }

    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }
}
