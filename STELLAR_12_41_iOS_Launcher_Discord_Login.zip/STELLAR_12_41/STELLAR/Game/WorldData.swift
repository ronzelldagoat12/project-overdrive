import SwiftUI

struct Skin: Identifiable, Equatable {
    let id: String
    let name: String
    let rarity: String
    let color: Color

    static let catalog: [Skin] = [
        Skin(id: "cipher", name: "Cipher", rarity: "Legendary Agent", color: .stellarGold),
        Skin(id: "nightfall", name: "Nightfall", rarity: "Epic Operative", color: .purple),
        Skin(id: "vanguard", name: "Vanguard", rarity: "Rare Specialist", color: .cyan),
        Skin(id: "ember", name: "Ember", rarity: "Uncommon Scout", color: .orange)
    ]
}

struct POI: Identifiable {
    let id: String
    let name: String
    let description: String
    let type: String
    let symbol: String
    let x: CGFloat
    let y: CGFloat

    static let catalog: [POI] = [
        POI(id: "citadel", name: "The Citadel", description: "Central agency headquarters", type: "HQ", symbol: "building.2.fill", x: 0.50, y: 0.48),
        POI(id: "helios", name: "Helios Harbor", description: "Cargo docks and warehouses", type: "Industrial", symbol: "ferry.fill", x: 0.78, y: 0.30),
        POI(id: "mirage", name: "Mirage Resort", description: "Coastal villas and pools", type: "Resort", symbol: "sun.max.fill", x: 0.25, y: 0.25),
        POI(id: "foundry", name: "Ironclad Foundry", description: "Factory with dense loot", type: "Industrial", symbol: "gearshape.2.fill", x: 0.22, y: 0.72),
        POI(id: "observatory", name: "Northstar Observatory", description: "Hilltop radar station", type: "Outpost", symbol: "binoculars.fill", x: 0.72, y: 0.72),
        POI(id: "village", name: "Pinewatch Village", description: "Quiet cabins in the woods", type: "Village", symbol: "house.fill", x: 0.49, y: 0.16)
    ]
}

struct ShopItem: Identifiable {
    let id: String
    let name: String
    let kind: String
    let price: Int
    let symbol: String
    let color: Color
}

enum ShopCatalog {
    static let all: [ShopItem] = [
        ShopItem(id: "golden-ghost", name: "Golden Ghost", kind: "Outfit", price: 1500, symbol: "person.fill", color: .stellarGold),
        ShopItem(id: "blacksite", name: "Blacksite Blade", kind: "Harvest Tool", price: 800, symbol: "bolt.fill", color: .cyan),
        ShopItem(id: "solar-wing", name: "Solar Wing", kind: "Glider", price: 1200, symbol: "paperplane.fill", color: .orange),
        ShopItem(id: "classified", name: "Classified Groove", kind: "Emote", price: 500, symbol: "figure.dance", color: .purple),
        ShopItem(id: "deep-cover", name: "Deep Cover", kind: "Outfit", price: 1200, symbol: "eye.slash.fill", color: .green),
        ShopItem(id: "ion-edge", name: "Ion Edge", kind: "Harvest Tool", price: 700, symbol: "scissors", color: .pink),
        ShopItem(id: "night-ops", name: "Night Ops", kind: "Wrap", price: 300, symbol: "circle.lefthalf.filled", color: .blue),
        ShopItem(id: "signal-boost", name: "Signal Boost", kind: "Emote", price: 400, symbol: "waveform", color: .yellow)
    ]

    static var dailyItems: [ShopItem] {
        let day = Calendar.current.ordinality(of: .day, in: .era, for: Date()) ?? 1
        let start = (day * 3) % all.count
        return (0..<5).map { all[(start + $0 * 2) % all.count] }
    }

    static var nextRotationText: String {
        let calendar = Calendar.current
        let tomorrow = calendar.startOfDay(for: Date()).addingTimeInterval(86400)
        let components = calendar.dateComponents([.hour, .minute], from: tomorrow)
        return String(format: "%02dH %02dM", components.hour ?? 0, components.minute ?? 0)
    }
}
